

<?php

  include('connection.php');

if (isset($_POST['submit'])) {

    $category = $_POST['category'];
    $name = $_POST['name'];
    $cost = $_POST['cost'];
    




 $sql = "INSERT INTO service ".
               "(service_categories ,service_name,cost) "."VALUES ".
               "('$category', '$name', '$cost')";

               
if (mysqli_query($con, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

}

?>
<html>
<head>
    <title>Service</title>

    <link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
    <div id = "frm">
        <h1>Service</h1>
        <form name="f1" action = ""  method = "POST">
            <p>
                <label>Service Categories: </label>
                <input type = "text" id ="user" name  = "category" />
            </p>
            <p>
                <label> Service Name: </label>
                <input type = "text" id ="pass" name  = "name" />
            </p>
            <p>
                <label>Cost: </label>
                <input type = "text" id ="pass" name  = "cost" />
            </p>
            <p>
                <input type =  "submit" id = "btn" value = "Submit" name="submit" />
            </p>
        </form>
    </div>

   
</body>
</html>
