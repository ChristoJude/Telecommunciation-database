<?php

  include('connection.php');

?>



<!DOCTYPE html>
<html>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

<h2>View Orders</h2>

<table style="width:100%">
  <tr>
    <th>Date Of Order</th>
    <th>Product</th>
    <th>Customer</th>
    <th>Cost</th>
    <th>Edit</th>
  </tr>
   <?php


$sql = "SELECT order_id,date_of_order , product_id ,customer_id, cost  FROM orders";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
 
?>
  <tr>
    <td><?php echo $row["date_of_order"];?></td>
    <td><?php echo $row["product_id"];?></td>
    <td><?php echo $row["customer_id"];?></td>
    <td><?php echo $row["cost"];?></td>
     <td> <a href="edit_order.php?id=<?php echo $row["order_id"];?>">Edit</a></td>
  </tr>
  <?php
  }
} else {
  echo "0 results";
}
?>
 
</table>



</body>
</html>

