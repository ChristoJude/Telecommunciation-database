<?php

  include('connection.php');



?>



<!DOCTYPE html>
<html>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

<h2>View Customer Registration</h2>

<table style="width:100%">
  <tr>
    <th>Coustomer Name</th>
    <th>Location</th>
    <th>Phone No</th>
     <th>Edit</th>
  </tr>
   <?php


$sql = "SELECT customer_id,customer_name, customer_location, customer_phoneno FROM customer";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
 
?>
  <tr>
    <td><?php echo $row["customer_name"];?></td>
    <td><?php echo $row["customer_location"];?></td>
    <td><?php echo $row["customer_phoneno"];?></td>
   <td> <a href="edit_customer.php?id=<?php echo $row["customer_id"];?>">Edit</a></td>
  </tr>
  <?php
  }
} else {
  echo "0 results";
}
?>
 
</table>



</body>
</html>

