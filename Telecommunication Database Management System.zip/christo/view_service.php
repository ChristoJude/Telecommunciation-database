<?php

  include('connection.php');

?>



<!DOCTYPE html>
<html>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

<h2>View Service</h2>

<table style="width:100%">
  <tr>
    <th>Service Categories</th>
    <th>Service Name</th>
    <th>Cost</th>
      <th>Edit</th>
  </tr>
   <?php


$sql = "SELECT service_id,service_categories , service_name ,cost  FROM service";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
 
?>
  <tr>
    <td><?php echo $row["service_categories"];?></td>
    <td><?php echo $row["service_name"];?></td>
    <td><?php echo $row["cost"];?></td>
     <td> <a href="edit_service.php?id=<?php echo $row["service_id"];?>">Edit</a></td>
  </tr>
  <?php
  }
} else {
  echo "0 results";
}
?>
 
</table>



</body>
</html>

