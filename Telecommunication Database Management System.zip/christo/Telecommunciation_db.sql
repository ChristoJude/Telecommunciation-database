-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2022 at 05:44 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCustomerByID` (IN `CNAME` VARCHAR(100))  BEGIN
select * from customer where customer_name=CNAME;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectAllCustomer` (IN `customer` VARCHAR(100))  BEGIN
 select * from customer;
 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `no_of_employees` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `location`, `no_of_employees`) VALUES
(101, 'Thiruvottiyur branch', 'Thiruvottiyur', 2),
(102, 'Tambaram branch', 'Tambaram', 2),
(103, 'Madurai branch', 'Madurai', 2),
(104, 'Vellore branch', 'Vellore', 2),
(105, 'Kumbakonam branch', 'Kumbakonam', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_location` varchar(100) NOT NULL,
  `customer_phoneno` int(10) NOT NULL,
  `del` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_location`, `customer_phoneno`, `del`) VALUES
(3, 'midhun', 'jubail', 98899999, 0),
(4, 'arun', 'chennai', 2147483647, 0),
(5, 'roshan', 'trichy', 2147483647, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer1`
--

CREATE TABLE `customer1` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(45) DEFAULT NULL,
  `customer_location` varchar(45) DEFAULT NULL,
  `customer_phoneno` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer1`
--

INSERT INTO `customer1` (`customer_id`, `customer_name`, `customer_location`, `customer_phoneno`) VALUES
(0, '$user', '$location', 0),
(1, 'wefwefwe', 'dad', 234234234);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `employee_name`, `position`, `salary`, `branch_id`) VALUES
(11, 'Joyel', 'Sales', 2500, 101),
(12, 'Zeshan', 'Sales', 2500, 105),
(13, 'Rayan', 'Manager', 5000, 102),
(14, 'Afzaal', 'Sales', 3000, 104),
(15, 'Ayaan', 'Sales', 1500, 103),
(16, 'Saish', 'Manager', 4500, 102),
(17, 'Mufeez', 'Technician', 2000, 103),
(18, 'Ragav', 'Technician', 2000, 105),
(19, 'Basil', 'Sales', 2500, 104),
(20, 'Mushrif', 'Technician', 1500, 101);

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `date_of_order` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `date_of_order` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `cost` varchar(10) NOT NULL,
  `del` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `date_of_order`, `product_id`, `customer_id`, `cost`, `del`) VALUES
(3, '2022-04-01', '1102', '4', '50', 0),
(4, '2022-03-28', '1101', '3', '60', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_id` int(10) NOT NULL,
  `service_categories` varchar(10) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `del` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `service_categories`, `service_name`, `cost`, `del`) VALUES
(2, 'Pre-paid', 'Pre-Paid Recharge ', '60', 0),
(3, 'Post-Paid', 'Post-Paid Recharge', '50', 0),
(4, 'DTH', 'DTH- Recharge', '650', 0),
(5, 'BroadBand', 'Network-Recharge ', '800', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service1`
--

CREATE TABLE `service1` (
  `product_id` int(11) NOT NULL,
  `service_categories` varchar(45) DEFAULT NULL,
  `service_name` varchar(45) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service1`
--

INSERT INTO `service1` (`product_id`, `service_categories`, `service_name`, `cost`) VALUES
(1101, 'Pre-paid', 'Pre-Paid Recharge', 60),
(1102, 'Post-Paid', 'Post-Paid Recharge', 50),
(1103, 'DTH', 'DTH- Recharge', 650),
(1104, 'BroadBand', 'Network-Recharge', 800);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `create_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `create_datetime`) VALUES
(1, 'ChristoDJ', 'chris@gmail.com', '123456', '2022-04-03 11:01:23'),
(2, 'Shaz', 'shaz@hello.world', '123', '2022-04-04 07:40:12'),
(3, 'Vysh', 'vysh@gmail.com', '12345', '2022-04-04 08:11:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer1`
--
ALTER TABLE `customer1`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service1`
--
ALTER TABLE `service1`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `service_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `branch_id` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order1`
--
ALTER TABLE `order1`
  ADD CONSTRAINT `customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer1` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `service1` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
