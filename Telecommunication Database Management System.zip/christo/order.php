<?php

  include('connection.php');

if (isset($_POST['submit'])) {

    $date = $_POST['date'];
    $product = $_POST['product'];
    $customers = $_POST['customers'];
     $cost = $_POST['cost'];




 $sql = "INSERT INTO orders ".
               "(date_of_order ,product_id,customer_id,cost) "."VALUES ".
               "('$date', '$product', '$customers', '$cost')";

;
               
if (mysqli_query($con, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);


}
}

?>


<html>
<head>
    <title>Order</title>

    <link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
    <div id = "frm">
        <h1>Order</h1>
        <form name="f1" action = "" onsubmit = "return validation()" method = "POST">
            <p>
                <label>Date of Order</label>
                <input type = "text" id ="user" name  = "date" />
            </p>
            <p>
                <label> Product </label>
                <input type = "text" id ="pass" name  = "product" />
            </p>
            <p>
                <label>Customer</label>
                <input type = "text" id ="pass" name  = "customers" />
            </p>
             <p>
                <label>Cost</label>
                <input type = "text" id ="pass" name  = "cost" />
            </p>'
            <p>
                <input type =  "submit" id = "btn" value = "Submit" name="submit" />
            </p>
        </form>
    </div>

   
</body>
</html>
