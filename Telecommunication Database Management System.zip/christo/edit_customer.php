<?php

  include('connection.php');

if (isset($_POST['submit'])) {

    $user = $_POST['user'];
    $location = $_POST['location'];
    $phone = $_POST['phone'];





 $sql = "INSERT INTO customer ".
               "(customer_name ,customer_location,customer_phoneno) "."VALUES ".
               "('$user', '$location', '$phone')";


if (mysqli_query($con, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

}

?>


<html>
<head>
    <title>Edit Customer Registration</title>

    <link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
    <div id = "frm">
        <h1>Edit Customer Registration</h1>
        <form name="f1" action = "" method = "POST">

          <?php
$id=$_GET['customer_id'];

$sql = "SELECT customer_name, customer_location, customer_phoneno FROM customer WHERE customer_id= '$id' ";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>
            <p>
                <label>Customer Name: </label>
                <input type = "text" id ="user" name  = "user" value="<?php echo $row["customer_name"];?>" />
            </p>
            <p>
                <label> Customer Location: </label>
                <input type = "text" id ="pass" name  = "location"  value="<?php echo $row["customer_location"];?>" />
            </p>
            <p>
                <label> Customer Phone No: </label>
                <input type = "text" id ="pass" name  = "phone" value="<?php echo $row["customer_phoneno"];?>" />
            </p>
            <p>
                <input type =  "submit" id = "btn" value = "Submit" name="submit" />
            </p>

            <?php

} }
            ?>
        </form>
    </div>


</body>
</html>
