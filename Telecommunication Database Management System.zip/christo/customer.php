<?php

  include('connection.php');

if (isset($_POST['submit'])) {

    $user = $_POST['user'];
    $location = $_POST['location'];
    $phone = $_POST['phone'];
    




 $sql = "INSERT INTO customer ".
               "(customer_name ,customer_location,customer_phoneno) "."VALUES ".
               "('$user', '$location', '$phone')";

              
if (mysqli_query($con, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

}

?>


<html>
<head>
    <title>Customer Registration</title>

    <link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
    <div id = "frm">
        <h1>Customer Registration</h1>
        <form name="f1" action = "" method = "POST">
            <p>
                <label>Customer Name: </label>
                <input type = "text" id ="user" name  = "user" />
            </p>
            <p>
                <label> Customer Location: </label>
                <input type = "text" id ="pass" name  = "location" />
            </p>
            <p>
                <label> Customer Phone No: </label>
                <input type = "text" id ="pass" name  = "phone" />
            </p>
            <p>
                <input type =  "submit" id = "btn" value = "Submit" name="submit" />
            </p>
        </form>
    </div>

   
</body>
</html>
